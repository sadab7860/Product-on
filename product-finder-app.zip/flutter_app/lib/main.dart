import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'dart:convert';
import 'dart:io';
import 'package:url_launcher/url_launcher.dart';

void main() => runApp(MaterialApp(home: ProductSearchPage()));

class ProductSearchPage extends StatefulWidget {
  @override
  _ProductSearchPageState createState() => _ProductSearchPageState();
}

class _ProductSearchPageState extends State<ProductSearchPage> {
  String message = '';
  List links = [];

  Future<void> uploadImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);
    if (pickedFile == null) return;

    var request = http.MultipartRequest(
      'POST',
      Uri.parse('http://10.0.2.2:8000/upload/'),
    );
    request.files.add(await http.MultipartFile.fromPath('file', pickedFile.path));

    var response = await request.send();
    final respStr = await response.stream.bytesToString();
    final result = jsonDecode(respStr);

    setState(() {
      message = result['message'] ?? '';
      links = result['products'] ?? [];
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Product Finder')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(children: [
          ElevatedButton(onPressed: uploadImage, child: Text("Upload Image")),
          SizedBox(height: 20),
          if (message.isNotEmpty) Text(message),
          for (var item in links)
            ListTile(
              title: Text(item['name']),
              subtitle: Text(item['link']),
              onTap: () => launchUrl(Uri.parse(item['link'])),
            )
        ]),
      ),
    );
  }
}
