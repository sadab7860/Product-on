import base64
import requests

def get_keywords(image_bytes):
    api_key = "YOUR_GOOGLE_API_KEY"
    url = f"https://vision.googleapis.com/v1/images:annotate?key={api_key}"

    image_base64 = base64.b64encode(image_bytes).decode()

    payload = {
        "requests": [{
            "image": {"content": image_base64},
            "features": [{"type": "LABEL_DETECTION", "maxResults": 5}]
        }]
    }

    res = requests.post(url, json=payload)
    if res.status_code != 200:
        return []

    labels = res.json()["responses"][0].get("labelAnnotations", [])
    return [label["description"] for label in labels]

def search_amazon(keywords):
    if "t-shirt" in [kw.lower() for kw in keywords]:
        return [{"name": "Blue Cotton T-Shirt", "link": "https://amazon.in/sample-tshirt"}]
    return []
