from fastapi import FastAPI, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from product_search import get_keywords, search_amazon

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/upload/")
async def upload_image(file: UploadFile = File(...)):
    image_bytes = await file.read()
    keywords = get_keywords(image_bytes)
    if not keywords:
        return {"status": "not_found", "message": "No product found"}

    links = search_amazon(keywords)
    if links:
        return {"status": "success", "products": links}
    else:
        return {"status": "not_found", "message": "No matching product found"}
